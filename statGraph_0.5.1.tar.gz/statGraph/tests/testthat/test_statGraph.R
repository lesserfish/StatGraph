# THIS SCRIPT IS INVOKED AUTOMATICALLY BY devtools::test()
# For Documentation on how to create tests, please refer to: https://cran.r-project.org/web/packages/testthat/testthat.pdf

# Parameter Estimator
test_parameter_estimator <- function(){

    G <- igraph::sample_gnp(n=50, p=0.5)
    result1 <- graph.param.estimator(G, "ER", eps=0.25)

    # Check whether error is less than 0.1
    OK <- (abs(result1$param - 0.5) <= 0.1)

    test_that("Parameter Estimator", {
                  expect(OK)
})
}
test_parameter_estimator()

