# Returns the adjacency matrix of an igraph object
get.adjacency.matrix <- function(G){
  if(methods::is(G, "igraph")) A <- as.matrix(igraph::get.adjacency(G)) else A <- G
  return(A)
}

# Returns the kernel bandwidth for a sample x based on Sturge's criterion
kernelBandwidth <- function(x){
  n <- length(x)
  nbins <- ceiling(log2(n) + 1)
  return(abs(max(x) - min(x)) / nbins)
}


# Given a partition x[1]...x[n] and y[i] = f(x[i]), returns the trapezoid sum
# approximation for int_{x[1]}^{x[n]}{f(x)dx}
trapezoidSum <- function(x, y){
  n <- length(x)
  delta <- (x[2] - x[1])
  area <- sum(y[2:(n-1)])
  area <- (area + (y[1] + y[n]) / 2) * delta
  return(area)
}


# Returns the density function for a sample x at n points in the interval [from, to]
gaussianDensity <- function(x, from=NULL, to=NULL, bandwidth="Silverman", npoints=1024){
  if(bandwidth == "Sturges"){
    bw <- kernelBandwidth(x)
  } else if(bandwidth == "Silverman"){
    bw <- bw.nrd0(x)
  } else if(bandwidth == "bcv"){
    bw <- suppressWarnings(bw.bcv(x))
  } else if(bandwidth == "ucv"){
    bw <- suppressWarnings(bw.ucv(x))
  } else if(bandwidth == "SJ"){
    bw <- "SJ"
  } else stop("Please, choose a valid bandwidth.")

  if(bw == 0) stop("Bandwidth cannot be zero.")

  if(is.null(from) || is.null(to)){
    f <- density(x, bw=bw, n=npoints)
  } else f <- density(x, bw=bw, from=from, to=to, n=npoints)

  # we do not want the area to be zero, so we add a very small number
  f$y = f$y + 1e-12

  area <- trapezoidSum(f$x, f$y)
  return(list("x" = f$x, "y" = f$y / area))
}


# Returns the spectral density for a given adjacency matrix A
spectralDensity <- function(A, from=NULL, to=NULL, bandwidth="Silverman", npoints=1024, directed=FALSE){
  eigenvalues <- as.numeric(eigen(A, only.values=TRUE, symmetric=TRUE)$values)
  eigenvalues <- eigenvalues / sqrt(nrow(A))
  return(gaussianDensity(eigenvalues, from, to, bandwidth, npoints))
}

nDensities <- function(spectra, from=NULL, to=NULL, bandwidth="Silverman", npoints=1024){
  ngraphs <- ncol(spectra)
  densities <- matrix(NA, npoints, ngraphs)
  minimum <- min(spectra)
  maximum <- max(spectra)
  if(!is.null(from) && !is.null(to)){
    minimum <- min(minimum, from)
    maximum <- max(maximum, to)
  }
  for(i in 1:ngraphs){
    f <- gaussianDensity(spectra[, i], bandwidth=bandwidth, from=minimum, to=maximum, npoints=npoints)
    if(sum(is.na(f)) > 0) return(NA)
    densities[, i] <- f$y
    x <- f$x
  }
  return(list("x" = x, "densities" = densities))
}

# Estimates the spectral density of a graph model
modelSpectralDensity <- function(fun, n, p, ngraphs=100, from=NULL, to=NULL, bandwidth="Silverman", npoints=1024){
  spectra <- matrix(NA, n, ngraphs)
  for(i in 1:ngraphs){
    A <- fun(n, p)
    A <- get.adjacency.matrix(A)
    eigenvalues <- (as.numeric(eigen(A, only.values=TRUE, symmetric=TRUE)$values) / sqrt(nrow(A)))
    spectra[,i] <- eigenvalues
  }
  densities <- matrix(NA, npoints, ngraphs)
  minimum <- min(spectra)
  maximum <- max(spectra)
  if(!is.null(from) && !is.null(to)){
    minimum <- min(minimum, from)
    maximum <- max(maximum, to)
  }
  for(i in 1:ngraphs){
    f <- gaussianDensity(spectra[, i], from=minimum, to=maximum, bandwidth=bandwidth, npoints=npoints)
    densities[, i] <- f$y
    x <- f$x
  }
  return(list("x" = x, "y" = rowMeans(densities)))
}

# Distance Functions
L2 <- function(f1, f2){
  y <- abs(f1$y - f2$y)
  return (trapezoidSum(f1$x,y))
}

# Returns the Kullback-Leibler divergence between two densities
KL <- function(f1, f2){
  y <- f1$y
  y <- ifelse(y != 0, y*log(y/f2$y), y)
  return (trapezoidSum(f1$x, y))
}


# Returns the Jensen-Shannon divergence between two densities
JS <- function(f1, f2){
  fm <- f1
  fm$y <- (f1$y + f2$y) / 2
  return((KL(f1, fm) + KL(f2, fm)) / 2)
}

# Extract a function specified by name
matchFunction <- function(name){
  return(match.fun(name))
}

# Padronize input.
f.transform <- function(g){
  if(methods::is(g, "igraph")) return(as.matrix(igraph::get.adjacency(g)))
  if(methods::is(g, "list") && methods::is(g[[1]],"igraph")){
    d <- lapply(g, f.transform)
    return(d)
  }
  if(methods::is(g, "list") && methods::is(g[[1]], "list")){
    d <- lapply(g, f.transform)
    return(d)
  }
}

# Returns the spectral densities for a list of adjacency matrices at the same points
nSpectralDensities <- function(adjacencyMatrices, from=NULL, to=NULL, bandwidth="Silverman"){
  npoints <- 1024
  ngraphs <- length(adjacencyMatrices)
  ns <- unlist(lapply(adjacencyMatrices, ncol))
  spectra <- matrix(NA, max(ns), ngraphs)
  for(i in 1:ngraphs){
    A <- adjacencyMatrices[[i]]
    n <- ncol(A)
    eigenvalues <- (as.numeric(eigen(A, only.values=TRUE, symmetric=TRUE)$values) / sqrt(n))
    spectra[1:n, i] <- eigenvalues
  }
  densities <- matrix(NA, npoints, ngraphs)
  minimum <- min(spectra, na.rm=TRUE)
  maximum <- max(spectra, na.rm=TRUE)
  if(!is.null(from) && !is.null(to)){
    minimum <- min(minimum, from)
    maximum <- max(maximum, to)
  }
  for(i in 1:ngraphs){
    n <- ns[i]
    f <- gaussianDensity(spectra[1:n,i], bandwidth=bandwidth, from=minimum, to=maximum, npoints=npoints)
    densities[,i] <- f$y
    x <- f$x
  }
  return(list("x" = x, "densities" = densities))
}

