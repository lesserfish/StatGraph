library("ks")
library("igraph")
library("parallel")
library("memoise")
source("../../../privatestat/statGraph/R/common.R")
source("../../../privatestat/statGraph/R/graph.param.estimator.R")
source("../../../privatestat/statGraph/R/graph.param.distance.R")

ER <- function(n, p)
{
    M <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
    N <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
    M[upper.tri(M)] <- 0
    N[lower.tri(N)] <- 0
    O <- M + N
    return(O)
}

PA <- function(m)
{
	out_func <- function(n, p)
	{
		M <- as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=m)))
		N <- t(as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=m))))
		M[upper.tri(M)] <- 0
		N[lower.tri(N)] <- 0
		O <- M + N
		return(O)
	}
	return(out_func)
}
WS <- function(nei)
{
	out_func <- function(n, p){
		M <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p)))
		N <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p)))
		M[upper.tri(M)] <- 0
		N[lower.tri(N)] <- 0
		O <- M + N
		return(O)
	}
	return(out_func)
}

# This function receives
# N: The size of the graph
# M: The model of the graph
# p: The parameter used to generate a graph
# search_domain: The domain in which to search for the parameter using grid search
# niter: How many iterations to run for
# model_name: The name of the model
#
# It outputs a sequence of niter numbers to disk.
# Each number in the sequence correspond to the result of running graph.param.estimator on M(N, p), 
# using grid search, with a search domain of search_domain

simulation.param.estimator <- function(thread, Model, N, p, search_domain, niter, model_name){
	cat("Starting thread ", thread, "\n")
	p_values <- c()
	q_values <- c()
	for(i in 1:niter){

		G <- Model(N, p)
		result <- graph.param.estimator(G=G, 
						model=Model, 
						parameters=search_domain, 
						directed=TRUE, 
						distance="L1",
						npoints=300, 
						ngraphs=5,
						from=c(-1, -1),
						to=c(1, 1),
						log=FALSE,
						search_mode="grid_search")
		p_values <- c(p_values, result$param[1])

		# Log progress
		filename = paste("simulation.param.estimator-", model_name, "-", N, "-progress-", thread, ".data", sep="")
		write(x=p_values, file=filename)
	}
	filename = paste("simulation.param.estimator-", model_name, "-", N, "-result-", thread, ".data", sep="")
	write(x=p_values, file=filename)
}

# This function receives
# N: The size of the graph
# M: The model of the graph
# p: The parameter used to generate a graph
# search_domain: The domain in which to search for the parameter using grid search
# niter: How many iterations to run for
# model_name: The name of the model
#
# It outputs a matrix to disk of size k x niter, where k = length(search_domain[[1]])
# Each row in the output matrix correspond to the y-values of a function evaluated at the search_domain
# The function is d(x) = L1( Spec(M(N, p), MSpec(M, N, x)), 
# where Spec(G) is the spectrum of a graph and MSpec(M, N, x) is the spectrum of a random graph model M with N elements and parameter x.

simulation.param.distance <- function(thread, Model, N, p, search_domain, niter, model_name){
	cat("Starting thread ", thread, "\n")
	p_values <- c()
	q_values <- c()

	ncols <- length(search_domain[[1]])
	nrows <- niter

	output <- matrix(0, nrow=nrows, ncol=ncols)

	for(i in 1:niter){

		G <- Model(N, p)
		result <- graph.param.distance(G=G, 
					       model=Model, 
					       parameters=search_domain, 
					       directed=TRUE, 
					       distance="L1",
					       npoints=300, 
					       ngraphs=5,
					       from=c(-1, -1),
					       to=c(1, 1),
					       log=FALSE,
					       search_mode="grid_search")
		output[i, ] <- result$distance
		# Log progress
		filename = paste("simulation.param.distance-", model_name, "-", N, "-progress-", thread, ".data", sep="")
		write.csv(output, filename, row.names=FALSE)
	}
	filename = paste("simulation.param.distance-", model_name, "-", N, "-result-", thread, ".data", sep="")
	write.csv(output, filename, row.names=FALSE)
}


# This function receives
# N: The size of the graph
# M: The model of the graph
# p: The parameter used to generate a graph
# search_domain: The domain in which to search for the parameter using grid search
# niter: How many iterations to run for
# model_name: The name of the model
#
# It outputs a matrix to disk of size k x niter, where k = length(search_domain[[1]])
# Each row in the output matrix correspond to the y-values of a function evaluated at the search_domain
# The function is d(x) = L1( Spec(M(N, p), MSpec(M, N, x)), 
# where Spec(G) is the spectrum of a graph and MSpec(M, N, x) is the spectrum of a random graph model M with N elements and parameter x.
simulation.size.variance <- function(N, Model, p, search_domain, niter, model_name){
	cat("Starting analysis with size ", N, "\n")
	p_values <- c()
	q_values <- c()

	ncols <- length(search_domain[[1]])
	nrows <- niter

	output <- matrix(0, nrow=nrows, ncol=ncols)

	for(i in 1:niter){

		G <- Model(N, p)
		result <- graph.param.distance(G=G, 
					       model=Model, 
					       parameters=search_domain, 
					       directed=TRUE, 
					       distance="L1",
					       npoints=300, 
					       ngraphs=5,
					       from=c(-1, -1),
					       to=c(1, 1),
					       log=FALSE,
					       search_mode="grid_search")
		output[i, ] <- result$distance
		# Log progress
		filename = paste("simulation.size.variance-", model_name, "-", N, "-progress-.data", sep="")
		write.csv(output, filename, row.names=FALSE)
	}
	filename = paste("simulation.size.variance-", model_name, "-", N, "-progress-.data", sep="")
	write.csv(output, filename, row.names=FALSE)
}



launch.simulation <- function(simulation, ncores, ...){
	s <- system.time ({mn <- mclapply(1:ncores, simulation, ..., mc.cores=ncores)});
}

launch.simulation.s <- function(simulation, ncores, space, ...){
	s <- system.time ({mn <- mclapply(space, simulation, ..., mc.cores=ncores)});
}
