source("./simulation.R")

launch.permanogva <- function(model = c("ER", "PA", "WS"), sample_counts = c(10, 30, 50, 70)){
    source("./simulation.R")
    setwd("~/Documents/NetworkPaper/MacRun/Code/Permanogva")
    if("ER" %in% model){
        for(sample_count in sample_counts){
            launch.simulation(simulation.permanogva, ncores = 50, niter = 10, sample_count = sample_count, N = 400, h0 = TRUE , model = ER, model_name = "ER")
            launch.simulation(simulation.permanogva, ncores = 50, niter = 10, sample_count = sample_count, N = 400, h0 = FALSE, model = ER, model_name = "ER")
        }
    }

    if("PA" %in% model){
        for(sample_count in sample_counts){  
            launch.simulation(simulation.permanogva, ncores = 50, niter = 10, sample_count = sample_count, N = 400, h0 = TRUE , model = PA(40), model_name = "PA")
            launch.simulation(simulation.permanogva, ncores = 50, niter = 10, sample_count = sample_count, N = 400, h0 = FALSE, model = PA(40), model_name = "PA")
         }
    }

    if("WS" %in% model){
        for(sample_count in sample_counts){  
            launch.simulation(simulation.permanogva, ncores = 50, niter = 10, sample_count = sample_count, N = 400, h0 = TRUE , model = WS(40), model_name = "WS")
            launch.simulation(simulation.permanogva, ncores = 50, niter = 10, sample_count = sample_count, N = 400, h0 = FALSE, model = WS(40), model_name = "WS")
         }
    }
}

launch.anogva <- function(model = c("ER", "PA", "WS"), eps = NULL, length.out = 8, N=400){
    setwd("~/Documents/NetworkPaper/MacRun/Code/Anogva")
    if(is.null(eps)){
        eps <- list(ER = seq(0 + 0.002, 0.002 + 0.002, length.out = length.out) ,
                    PA = seq(0 + 0.015, 0.015 + 0.015, length.out = length.out) ,
                    WS = seq(0 + 0.003, 0.003 + 0.003, length.out = length.out))
    }
    if("ER" %in% model){
        for(e in eps[['ER']]){
            launch.simulation.s(simulation.anogva, ncores=10, space = 1:50, niter=10, N=N, p1=0.3, eps=e, h0 = FALSE, model = ER, model_name="ER")
        }
    }
    if("PA" %in% model){
        for(e in eps[['PA']]){
            launch.simulation.s(simulation.anogva, ncores=10, space = 1:50, niter=10, N=N, p1=0.3, eps=e, h0 = FALSE, model = PA(40), model_name="PA")
        }
    }
    if("WS" %in% model){
        for(e in eps[['WS']]){
            launch.simulation.s(simulation.anogva, ncores=10, space = 1:50, niter=10, N=N, p1=0.3, eps=e, h0 = FALSE, model = WS(40), model_name="WS")
        }
    }
}
