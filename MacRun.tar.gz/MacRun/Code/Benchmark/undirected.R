library("igraph")
library("statGraph")
library("parallel")
library("rbenchmark")

NCORES <- 50

ER <- function(n, p)
{
    M <- igraph::sample_gnp(n, p)
    return(M)
}
PA <- function(n, p)
{
    m <- n / 10
	M <- igraph::sample_pa(n=n, power=1 * p + 0.001, m=m)
	return(M)
}

WS <- function(n, p)
{
    nei <- n / 10
	M <- igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p)
	return(M)
}


param.estimator <- function(N, Model = ER, p = 0.35, interval=seq(0.1, 0.9, 0.01), model_name = "ER"){
	cat("Starting Param Estimator. Thread; N = ", N, "\n")
	G <- Model(N, p)
	result <- statGraph::graph.param.estimator(Graph=G, 
					model=Model, 
                    interval=interval)

	p_value <- result$param
	filename = paste("undirected-out/simulation.param.estimator-", model_name, "-", N, "-result.data", sep="")
	write(x=p_value, file=filename, append=TRUE)
}

model.selection <- function(N, Model = ER, p = 0.35, model_list = list(ER, PA, WS), search_domain=seq(0.1, 0.9, 0.01), model_name = "ER")
{
  cat("Starting Model Selection. Thread ", N, "\n")
  G <- Model(N, p)
  result <- graph.model.selection(G, 
                        model_list, 
                        search_domain)
    
  GIC <- result$estimates[,2]
  filename = paste("undirected-out/simulation.model.selection-", model_name, "-", N, "-result.data", sep="")
  write.csv(GIC, filename, row.names=FALSE)

}


bench.param.estimator <- function(N) {
    b <- benchmark( param.estimator(N), replications = rep(1, 30) )
	filename = paste("undirected-time/bench.param.estimator-", N, "-result.data", sep="")
    write.table(as.data.frame(b), file=filename)
}

bench.model.selection <- function(N) {
    b <- benchmark( model.selection(N), replications = rep(1, 30) )
	filename = paste("undirected-time/bench.model.selection-", N, "-result.data", sep="")
    write.table(as.data.frame(b), file=filename)
}

launch.param.estimator <- function(){
    space <- seq(100, 500, 5)
	mclapply(space, bench.param.estimator, mc.cores=NCORES);
}

launch.model.selection <- function(){
    space <- seq(100, 500, 5)
	mclapply(space, bench.model.selection, mc.cores=NCORES);
}
