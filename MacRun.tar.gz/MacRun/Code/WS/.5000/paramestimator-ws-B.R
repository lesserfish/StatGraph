library("ks")
library("igraph")
library("parallel")
library("memoise")
source("../../../privatestat/statGraph/R/common.R")
source("../../../privatestat/statGraph/R/graph.param.estimator.R")

#anogva

niter <- 10
ncores <- 50

WS <- function(n, p)
{
        M <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=p, p=0.35)))
        N <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=p, p=0.35)))
        M[upper.tri(M)] <- 0
        N[lower.tri(N)] <- 0
        O <- M + N
        return(O)
}

Thread <- function(thread){
	cat("Starting thread ", thread, "\n")
	p_values <- c()
	q_values <- c()
	for(i in 1:niter){
		G <- WS(1000, 300)
		result <- graph.param.estimator(G=G, model=WS, parameters=list(min=c(100), max=c(1000), eps=c(1)), directed=TRUE, distance="L1",npoints=500, ngraphs=40,search_mode = "grid_search") 
		print(result)

		params <- result$param
		filename = paste("paramestimator-ws-1000-B-progress-", thread, ".data", sep="")
		f <- file(filename, "a")
		writeLines(paste("Iteration: ", i, sep=""), f)
		writeLines(paste(params, sep="-"), f)
		close(f)

		p_values <- c(p_values, result$param[1])
	}
	filename = paste("paramestimator-ws-1000-B-core-p-", thread, ".data", sep="")
	write(x=p_values, file=filename)
}

s <- system.time ({mn <- mclapply(1:ncores, Thread, mc.cores=ncores)});
