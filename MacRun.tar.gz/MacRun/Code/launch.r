source("./run.R")
WSL = seq(0, 0.003, length.out = 8)
launch.anogva(model = "WS", eps = list(WS = WSL[7]))
launch.anogva(model = "WS", eps = list(WS = WSL[8]))
