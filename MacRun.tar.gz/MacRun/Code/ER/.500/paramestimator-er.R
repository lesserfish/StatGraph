library("ks")
library("igraph")
library("parallel")
library("memoise")
source("../../../privatestat/statGraph/R/common.R")
source("../../../privatestat/statGraph/R/graph.param.estimator.R")

#anogva

niter <- 20
ncores <- 50


ER <- function(n, p)
{
	M <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
	N <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
	M[upper.tri(M)] <- 0
	N[lower.tri(N)] <- 0
	O <- M + N
	return(O)
}

Thread <- function(thread){
	cat("Starting thread ", thread, "\n")
	p_values <- c()
	q_values <- c()
	for(i in 1:niter){
		G <- ER(500, 0.35)
		result <- graph.param.estimator(G=G, model=ER, parameters=list(min=c(0.1), max=c(0.9), eps=c(0.05)), directed=TRUE, distance="L1",npoints=200, ngraphs=30, use_grid_optimization = TRUE, grid_optimization_parameters = list("min" = 0.1, "max" = 0.9, "spacing" = 0.05), log=TRUE)
		print(result)

		params <- result$param
		filename = paste("paramestimator-er-1000-progress-", thread, ".data", sep="")
		f <- file(filename, "a")
		writeLines(paste("Iteration: ", i, sep=""), f)
		writeLines(paste(params, sep="-"), f)
		close(f)

		p_values <- c(p_values, result$param[1])
	}
	filename = paste("paramestimator-er-1000-core-p-", thread, ".data", sep="")
	write(x=p_values, file=filename)
}

s <- system.time ({mn <- mclapply(1:ncores, Thread, mc.cores=ncores)});
