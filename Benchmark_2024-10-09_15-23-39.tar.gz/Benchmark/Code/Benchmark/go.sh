#!/bin/bash
Rscript go.R 1
Rscript go.R 2
Rscript go.R 3
Rscript go.R 4
