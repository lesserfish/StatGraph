setwd("/home/vchavauty/R/Network-Paper/New/PA/400")
source("../../simulation.R")
launch.simulation(simulation.anogva, 50, 10, 400, 0.2, 0.007, FALSE, PA(40), "PA")
launch.simulation(simulation.anogva, 50, 10, 400, 0.2, 0.008, FALSE, PA(40), "PA")
