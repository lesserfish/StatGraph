#!/bin/bash
Rscript go.R 4
