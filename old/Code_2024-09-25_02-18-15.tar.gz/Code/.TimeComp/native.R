library("igraph")
library("statGraph")
library("parallel")

ER <- function(n, p)
{
    M <- igraph::sample_gnp(n, p)
    return(M)
}

PA <- function(m)
{
	out_func <- function(n, p)
	{
		M <- igraph::sample_pa(n=n, power=1 * p + 0.001, m=m)
		return(M)
	}
	return(out_func)
}

WS <- function(nei)
{
	out_func <- function(n, p){
		M <- igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p)
		return(M)
	}
	return(out_func)
}

simulation.param.estimator <- function(thread, Model, N, p, interval, niter, model_name){
	cat("Starting thread ", thread, "\n")
	p_values <- c()
	for(i in 1:niter){
		G <- Model(N, p)
		result <- statGraph::graph.param.estimator(Graph=G, 
						model=Model, 
                        interval=interval)

		p_values <- c(p_values, result$param)

		# Log progress
		filename = paste("simulation.native.param.estimator-", model_name, "-", N, "-progress-", thread, ".data", sep="")
		write(x=p_values, file=filename)
	}
	filename = paste("simulation.native.param.estimator-", model_name, "-", N, "-result-", thread, ".data", sep="")
	write(x=p_values, file=filename)
}

simulation.model.selection <- function(N, model, p, model_list, search_domain, nsamples, model_name)
{
  cat("Starting thread ", N, "\n")
  
  output <- matrix(NA, nrow=nsamples, ncol=length(model_list))
  
  for(i in 1:nsamples)
  {
    G <- model(N, p)
    result <- graph.model.selection(G, 
                          model_list, 
                          search_domain)
    
    GIC <- result$estimates[,2]
    print(GIC)
    output[i, ] <- GIC
    
    filename = paste("simulation.native.model.selection-", model_name, "-", N, "-progress", ".data", sep="")
    write.csv(output, filename, row.names=FALSE)
  }
  
  filename = paste("simulation.nativemodel.selection-", model_name, "-", N, "-result", ".data", sep="")
  write.csv(output, filename, row.names=FALSE)
}

timeit <- function(func, filepath){
    return(function(...){
        s <- system.time(func(...))
	    content <- paste(s["elapsed"])
	    write(content, file = filepath, append=TRUE)
    })
}

launch.simulation <- function(simulation, ncores, ...){
    filepath <- paste0(deparse(substitute(simulation)), "_native_time.txt")
	s <- system.time ({mn <- mclapply(1:ncores, timeit(simulation, filepath), ..., mc.cores=ncores)});
}
launch.simulation.s <- function(simulation, ncores, space, ...){
    filepath <- paste0(deparse(substitute(simulation)), "_native_time.txt")
	s <- system.time ({mn <- mclapply(space, timeit(simulation, filepath), ..., mc.cores=ncores)});
}


