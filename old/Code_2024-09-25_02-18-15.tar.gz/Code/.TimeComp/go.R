source("simulation.R")

#sd <- list(list(min=0.1, max=0.9, eps=0.01), list(min=0.1, max=0.9, eps=0.01), list(min=0.1, max=0.9, eps=0.01))
sd <- list(seq(0.1, 0.9, 0.01), seq(0.1, 0.9, 0.01), seq(0.1, 0.9, 0.01))

ERP <- ER
WSP <- function(n, p){return(WS(n / 10)(n ,p))}
PAP <- function(n, p){return(PA(n / 10)(n ,p))}


launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), ERP, 0.3, list(ERP, PAP, WSP), sd, 1, "ERP")
launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), ERP, 0.3, list(ERP, PAP, WSP), sd, 1, "ERP")
launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), ERP, 0.3, list(ERP, PAP, WSP), sd, 1, "ERP")
launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), PAP, 0.3, list(ERP, PAP, WSP), sd, 1, "PAP")
launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), WSP, 0.3, list(ERP, PAP, WSP), sd, 1, "WSP")


# source("native.R")
#
# sd <- list(seq(0.1, 0.9, 0.01), seq(0.1, 0.9, 0.01), seq(0.1, 0.9, 0.01))
#
# ERP <- ER
# WSP <- function(n, p){return(WS(n / 10)(n ,p))}
# PAP <- function(n, p){return(PA(n / 10)(n ,p))}
#
# launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), ERP, 0.3, list(ERP, PAP, WSP), sd, 1, "ERP")
# launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), ERP, 0.3, list(ERP, PAP, WSP), sd, 1, "ERP")
# launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), ERP, 0.3, list(ERP, PAP, WSP), sd, 1, "ERP")
# launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), PAP, 0.3, list(ERP, PAP, WSP), sd, 1, "PAP")
# launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), WSP, 0.3, list(ERP, PAP, WSP), sd, 1, "WSP")

