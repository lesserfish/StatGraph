library("ks")
library("igraph")
library("parallel")
library("memoise")
source("../../../privatestat/statGraph/R/common.R")
source("../../../privatestat/statGraph/R/graph.param.estimator.R")

ER <- function(n, p)
{
    M <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
    N <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
    M[upper.tri(M)] <- 0
    N[lower.tri(N)] <- 0
    O <- M + N
    return(O)
}

PA <- function(n, p)
{
	M <- as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=10)))
	N <- t(as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=10))))
	M[upper.tri(M)] <- 0
	N[lower.tri(N)] <- 0
	O <- M + N
	return(O)
}

WS <- function(n, p)
{
    M <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=50, p=p)))
    N <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=50, p=p)))
    M[upper.tri(M)] <- 0
    N[lower.tri(N)] <- 0
    O <- M + N
    return(O)
}


simulation.param.estimator <- function(thread, Model, N, p, niter, model_name){
	cat("Starting thread ", thread, "\n")
	p_values <- c()
	q_values <- c()
	for(i in 1:niter){

		G <- Model(N, p)
		result <- graph.param.estimator(G=G, 
                                        model=Model, 
                                        parameters=list(min=c(0.1), max=c(0.9), eps=c(0.01)), 
                                        directed=TRUE, 
                                        distance="L1",
                                        npoints=400, 
                                        ngraphs=10,
                                        from=c(-1, -1),
                                        to=c(1, 1),
                                        log=TRUE,
                                        search_mode="grid_search")
		params <- result$param
		p_values <- c(p_values, result$param[1])

        # Log progress
		filename = paste("simulation.param.estimator-", model_name, "-", N, "-progress-", thread, ".data", sep="")
	    write(x=p_values, file=filename)
	}
	filename = paste("paramestimator-ws-500-core-p-", thread, ".data", sep="")
	write(x=p_values, file=filename)
}



launch.simulation <- function(simulation, ncores, ...){
    s <- system.time ({mn <- mclapply(1:ncores, simulation, ..., mc.cores=ncores)});
}
