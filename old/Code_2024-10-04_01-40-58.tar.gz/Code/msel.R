source("~/R/Network-Paper/New/simulation.R")

setwd("~/R/Network-Paper/New/ModelSelection")

ERP <- ER
WSP <- function(n, p){return(WS(n / 10)(n ,p))}
PAP <- function(n, p){return(PA(n / 10)(n ,p))}

sd <- list(list(min=0.1, max=0.9, eps=0.01), list(min=0.1, max=0.9, eps=0.01), list(min=0.1, max=0.9, eps=0.01))

launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), ERP, 0.3, list(ERP, PAP, WSP), sd, 100, "ERP")
launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), PAP, 0.3, list(ERP, PAP, WSP), sd, 100, "PAP")
launch.simulation.s(simulation.model.selection, 50, seq(20, 120, 1), WSP, 0.3, list(ERP, PAP, WSP), sd, 100, "WSP")
