#!/bin/bash
Rscript go.R 1
Rscript go.R 2
