library("ks")
library("igraph")
library("parallel")
library("memoise")
library("pracma")
library("cluster")
library("aricode")
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/common.R")
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/graph.param.estimator.R")
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/graph.param.distance.R")
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/permanogva.R")
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/anogva.R")
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/graph.model.selection.R")

ER <- function(n, p)
{
    M <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
    N <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
    M[upper.tri(M)] <- 0
    N[lower.tri(N)] <- 0
    O <- M + N
    return(O)
}

ER2 <- function(n, p1, p2)
{
    M <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p1)))
    N <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p2)))
    M[upper.tri(M)] <- 0
    N[lower.tri(N)] <- 0
    O <- M + N
    return(O)
}

PA <- function(m)
{
	out_func <- function(n, p)
	{
		M <- as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=m)))
		N <- t(as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=m))))
		M[upper.tri(M)] <- 0
		N[lower.tri(N)] <- 0
		O <- M + N
		return(O)
	}
	return(out_func)
}
PA2 <- function(m)
{
	out_func <- function(n, p1, p2)
	{
		M <- as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p1 + 0.001, m=m)))
		N <- t(as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p2 + 0.001, m=m))))
		M[upper.tri(M)] <- 0
		N[lower.tri(N)] <- 0
		O <- M + N
		return(O)
	}
	return(out_func)
}

WS <- function(nei)
{
	out_func <- function(n, p){
		M <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p)))
		N <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p)))
		M[upper.tri(M)] <- 0
		N[lower.tri(N)] <- 0
		O <- M + N
		return(O)
	}
	return(out_func)
}

WS2 <- function(nei)
{
	out_func <- function(n, p1, p2){
		M <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p1)))
		N <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p2)))
		M[upper.tri(M)] <- 0
		N[lower.tri(N)] <- 0
		O <- M + N
		return(O)
	}
	return(out_func)
}

# This function receives
# N: The size of the graph
# M: The model of the graph
# p: The parameter used to generate a graph
# search_domain: The domain in which to search for the parameter using grid search
# niter: How many iterations to run for
# model_name: The name of the model
#
# It outputs a sequence of niter numbers to disk.
# Each number in the sequence correspond to the result of running graph.param.estimator on M(N, p), 
# using grid search, with a search domain of search_domain

simulation.param.estimator <- function(thread, Model, N, p, search_domain, niter, model_name){
	cat("Starting thread ", thread, "\n")
	p_values <- c()
	q_values <- c()
	for(i in 1:niter){

		G <- Model(N, p)
		result <- graph.param.estimator(G=G, 
						model=Model, 
						parameters=search_domain, 
						directed=TRUE, 
						distance="L1",
						npoints=300, 
						ngraphs=5,
						from=c(-1, -1),
						to=c(1, 1),
						log=FALSE,
						search_mode="grid_search")
		p_values <- c(p_values, result$param[1])

		# Log progress
		filename = paste("simulation.param.estimator-", model_name, "-", N, "-progress-", thread, ".data", sep="")
		write(x=p_values, file=filename)
	}
	filename = paste("simulation.param.estimator-", model_name, "-", N, "-result-", thread, ".data", sep="")
	write(x=p_values, file=filename)
}

simulation.param.estimator2 <- function(thread, Model, N, p1, p2, search_domain, niter, model_name){
	cat("!Starting thread ", thread, "\n")
	p_values <- matrix(NA, nrow=niter, ncol=2)
	for(i in 1:niter){

		G <- Model(N, p1, p2)
		result <- graph.param.estimator(G=G, 
						model=Model, 
						parameters=search_domain, 
						directed=TRUE, 
						distance="L1",
						npoints=300, 
						ngraphs=5,
						from=c(-1, -1),
						to=c(1, 1),
						log=FALSE,
						search_mode="ternary_search")
        print(result)
        print(result$param)
		p_values[i,] <- result$param

		# Log progress
		filename = paste("simulation.param.estimator2-", model_name, "-", N, "-progress-", thread, ".data", sep="")
		write.csv(p_values, file=filename, row.names=FALSE)
	}
	filename = paste("simulation.param.estimator2-", model_name, "-", N, "-result-", thread, ".data", sep="")
	write.csv(p_values, file=filename, row.names=FALSE)
}

# This function receives
# N: The size of the graph
# M: The model of the graph
# p: The parameter used to generate a graph
# search_domain: The domain in which to search for the parameter using grid search
# niter: How many iterations to run for
# model_name: The name of the model
#
# It outputs a matrix to disk of size k x niter, where k = length(search_domain[[1]])
# Each row in the output matrix correspond to the y-values of a function evaluated at the search_domain
# The function is d(x) = L1( Spec(M(N, p), MSpec(M, N, x)), 
# where Spec(G) is the spectrum of a graph and MSpec(M, N, x) is the spectrum of a random graph model M with N elements and parameter x.

simulation.param.distance <- function(thread, Model, N, p, search_domain, niter, model_name){
	cat("Starting thread ", thread, "\n")
	p_values <- c()
	q_values <- c()

	ncols <- length(search_domain[[1]])
	nrows <- niter

	output <- matrix(0, nrow=nrows, ncol=ncols)

	for(i in 1:niter){

		G <- Model(N, p)
		result <- graph.param.distance(G=G, 
					       model=Model, 
					       parameters=search_domain, 
					       directed=TRUE, 
					       distance="L1",
					       npoints=300, 
					       ngraphs=5,
					       from=c(-1, -1),
					       to=c(1, 1),
					       log=FALSE,
					       search_mode="grid_search")
		output[i, ] <- result$distance
		# Log progress
		filename = paste("simulation.param.distance-", model_name, "-", N, "-progress-", thread, ".data", sep="")
		write.csv(output, filename, row.names=FALSE)
	}
	filename = paste("simulation.param.distance-", model_name, "-", N, "-result-", thread, ".data", sep="")
	write.csv(output, filename, row.names=FALSE)
}


# This function receives
# N: The size of the graph
# M: The model of the graph
# p: The parameter used to generate a graph
# search_domain: The domain in which to search for the parameter using grid search
# niter: How many iterations to run for
# model_name: The name of the model
#
# It outputs a matrix to disk of size k x niter, where k = length(search_domain[[1]])
# Each row in the output matrix correspond to the y-values of a function evaluated at the search_domain
# The function is d(x) = L1( Spec(M(N, p), MSpec(M, N, x)), 
# where Spec(G) is the spectrum of a graph and MSpec(M, N, x) is the spectrum of a random graph model M with N elements and parameter x.
simulation.size.variance <- function(N, Model, p, search_domain, niter, model_name){
	cat("Starting analysis with size ", N, "\n")
	p_values <- c()
	q_values <- c()

	ncols <- length(search_domain[[1]])
	nrows <- niter

	output <- matrix(0, nrow=nrows, ncol=ncols)

	for(i in 1:niter){

		G <- Model(N, p)
		result <- graph.param.distance(G=G, 
					       model=Model, 
					       parameters=search_domain, 
					       directed=TRUE, 
					       distance="L1",
					       npoints=300, 
					       ngraphs=5,
					       from=c(-1, -1),
					       to=c(1, 1),
					       log=FALSE,
					       search_mode="grid_search")
		output[i, ] <- result$distance
		# Log progress
		filename = paste("simulation.size.variance-", model_name, "-", N, "-progress-.data", sep="")
		write.csv(output, filename, row.names=FALSE)
	}
	filename = paste("simulation.size.variance-", model_name, "-", N, "-progress-.data", sep="")
	write.csv(output, filename, row.names=FALSE)
}
simulation.permanogva <- function(thread, niter, sample_count, N, h0, model, model_name){
  cat("Starting thread ", thread, "\n")

  if(!h0)
  {
      p_values <- c()

      for(i in 1:niter){
        V1 <- rnorm(sample_count, 0.0, 1.0)
        V2<-  rnorm(sample_count, 0.0, 1.0)
        V3 <- rnorm(sample_count, 0.0, 1.0)
        Norm <-  rnorm(sample_count, 0.0, 1.0)

        #weight <-  sigmoid(rnorm(n, 0.5, 0.1)) # Covariance does not exist
        Y <- 0.5 * V1 - 0.5 * V2 + Norm
        P <- sigmoid(Y, a = 1, b = 0)# Non-Linear Covariance exists
        Graphs <- list()
        for(i in 1:sample_count){
          p <- P[i]
          G <- model(N, p)
          Graphs[[i]] <- G
        }
        Data <- matrix(NA, nrow = sample_count, ncol = 3)
        Data[,1] <- V1
        Data[,2] <- V2
        Data[,3] <- V3

        predictor = as.matrix(Data[,c(1, 2)]) # We use a related (V1, V2) variable
        result <- permanogva(Graphs, predictor, maxBoot = 1000, directed=TRUE, npoints = 500, trick = TRUE)
        print(result)
        p <- result$pvalue
        p_values <- c(p_values, p)

        filename = paste("simulation.permanogva-h1-", model_name, "-", N, "-", sample_count, "-progress-",thread, ".data", sep="")
        write(x=p_values, file=filename)
      }
      filename = paste("simulation.permanogva-h1-", model_name, "-", N, "-", sample_count, "-result-", thread, ".data", sep="")
      write(x=p_values, file=filename)
  }
  else
  {
      p_values <- c()

      for(i in 1:niter){
        V1 <- rnorm(sample_count, 0.0, 1.0)
        V2<-  rnorm(sample_count, 0.0, 1.0)
        V3 <- rnorm(sample_count, 0.0, 1.0)
        Norm <-  rnorm(sample_count, 0.0, 1.0)

        #weight <-  sigmoid(rnorm(n, 0.5, 0.1)) # Covariance does not exist
        Y <- 0.5 * V1 - 0.5 * V2 + Norm
        P <- sigmoid(Y, a = 1, b = 0)# Non-Linear Covariance exists
        Graphs <- list()
        for(i in 1:sample_count){
          p <- P[i]
          G <- model(N, p)
          Graphs[[i]] <- G
        }
        Data <- matrix(NA, nrow = sample_count, ncol = 3)
        Data[,1] <- V1
        Data[,2] <- V2
        Data[,3] <- V3

        predictor = as.matrix(Data[,c(3)]) # We use an unrelated (V3) variable
        result <- permanogva(Graphs, predictor, maxBoot = 1000, directed=TRUE, npoints = 500, trick = TRUE)
        print(result)
        p <- result$pvalue
        p_values <- c(p_values, p)

        filename = paste("simulation.permanogva-h0-", model_name, "-", N, "-", sample_count,"-progress-", thread, ".data", sep="")
        write(x=p_values, file=filename)
      }
      filename = paste("simulation.permanogva-h0-", model_name, "-", N, "-", sample_count, "-result-", thread, ".data", sep="")
      write(x=p_values, file=filename)
  }
}
simulation.anogva <- function(thread, niter, N, p1, eps,h0, model, model_name){
  cat("Starting thread ", thread, "\n")
  
  if(!h0)
  {
    p_values <- c()
    for(i in 1:niter){
      ngraphs <- 10
      MatricesA <- list()
      MatricesB <- list()
      MatricesC <- list()
      
      for(i in 1:ngraphs){
        G <- model(N, p1)
        H <- model(N, p1)
        I <- model(N, p1 + eps)
        MatricesA[[i]] <- G
        MatricesB[[i]] <- H
        MatricesC[[i]] <- I
      }
      
      G <- c(MatricesA, MatricesB, MatricesC)
      label <- c(rep(1,10),rep(2,10),rep(3,10))
      result <- anogva(G, label, maxBoot=100, directed=TRUE, distance = "KL", npoints=512)
      p_values <- c(p_values, result$p.value)
      print(p_values)
      filename = paste("simulation.anogva-h1-", model_name, "-", N, "-", eps, "-progress-", thread, ".data", sep="")
      write(x=p_values, file=filename)
    }
    filename = paste("simulation.anogva-h1-", model_name, "-", N, "-", eps,"-result-", thread, ".data", sep="")
    write(x=p_values, file=filename)
  }
  else
  {
    p_values <- c()
    for(i in 1:niter){
      ngraphs <- 10
      MatricesA <- list()
      MatricesB <- list()
      MatricesC <- list()
      
      for(i in 1:ngraphs){
        G <- model(N, p1)
        H <- model(N, p1)
        I <- model(N, p1 + eps)
        MatricesA[[i]] <- G
        MatricesB[[i]] <- H
        MatricesC[[i]] <- I
      }
      
      G <- c(MatricesA, MatricesB, MatricesC)
      label <- c(rep(1,10),rep(2,10),rep(3,10))
      result <- anogva(G, label, maxBoot=100, directed=TRUE, distance = "KL", npoints=512)
      p_values <- c(p_values, result$p.value)
      print(p_values)
      filename = paste("simulation.anogva-h0-", model_name, "-", N, "-", eps, "-progress-", thread, ".data", sep="")
      write(x=p_values, file=filename)
    }
    filename = paste("simulation.anogva-h0-", model_name, "-", N, "-", eps, "-result-", thread, ".data", sep="")
    write(x=p_values, file=filename)
  }
}
simulation.kmedoids <- function(N, p1, epsilon_list, ngraphs, nsamples, model, model_name)
{
  cat("Starting thread ", N, "\n")
  ari_data <- data.frame()
  for(eps in epsilon_list)
  {
    ari_values <- c()
    for(i in 1:nsamples){

      Specs <- list()

      for(i in 1:ngraphs){
        G <- model(N, p1)
        specG <- spectralDensity(G, directed=TRUE, npoints = 100)
        Specs[[i]] <- specG
      }
      for(i in 1:ngraphs){
        G <- model(N, p1 + eps)
        specG <- spectralDensity(G, directed=TRUE, npoints = 100)
        Specs[[ngraphs + i]] <- specG
      }

      D <- matrix(0, nrow=ngraphs*2, ncol=ngraphs*2)
      for(i in 1:(ngraphs * 2 - 1))
      {
        for(j in (i+1):(2 * ngraphs))
        {
          spec_i <- Specs[[i]]
          spec_j <- Specs[[j]]
          d <- Dist(spec_i, spec_j, "KL")
          D[i, j] <- d
          D[j, i] <- d
        }
      }

      classification <- c(rep(1,ngraphs), rep(2, ngraphs))
      result <- pam(D, k = 2)

      a <- ARI(result$clustering, classification)
      ari_values <- c(ari_values, a)
    }
    ari_mean <- mean(ari_values)
    ari_variance <- var(ari_values)

    cat("Eps: ", eps, "  Mean: ", ari_mean, "  Variance: ", ari_variance, "\n")
    ari_data <- rbind(ari_data, c(eps, ari_values))

    filename = paste("simulation.kmedoids-", model_name, "-", N, "-progress", ".data", sep="")
    save(ari_data, file=filename)
  }

  filename = paste("simulation.kmedoids-", model_name, "-", N, "-result", ".data", sep="")
  save(ari_data, file=filename)
}

simulation.model.selection <- function(N, model, p, model_list, search_domain, nsamples, model_name)
{
  cat("Starting thread ", N, "\n")
  
  output <- matrix(NA, nrow=nsamples, ncol=length(model_list))
  
  for(i in 1:nsamples)
  {
    G <- model(N, p)
    result <- graph.model.selection(G, 
                          model_list, 
                          search_domain, 
                          directed=TRUE, 
                          from=c(-1, -1), 
                          to=c(1, 1),
                          search_mode="grid_search")
    
    GIC <- result$estimates[,2]
    print(GIC)
    output[i, ] <- GIC
    
    filename = paste("simulation.model.selection-", model_name, "-", N, "-progress", ".data", sep="")
    write.csv(output, filename, row.names=FALSE)
  }
  
  filename = paste("simulation.model.selection-", model_name, "-", N, "-result", ".data", sep="")
  write.csv(output, filename, row.names=FALSE)
}

timeit <- function(func, filepath){
    return(function(...){
        s <- system.time(func(...))
	    content <- paste(s["elapsed"])
	    write(content, file = filepath, append=TRUE)
    })
}

launch.simulation <- function(simulation, ncores, ...){
    filepath <- paste0(deparse(substitute(simulation)), "_time.txt")
	s <- system.time ({mn <- mclapply(1:ncores, timeit(simulation, filepath), ..., mc.cores=ncores)});
}
launch.simulation.s <- function(simulation, ncores, space, ...){
    filepath <- paste0(deparse(substitute(simulation)), "_time.txt")
	s <- system.time ({mn <- mclapply(space, timeit(simulation, filepath), ..., mc.cores=ncores)});
}
