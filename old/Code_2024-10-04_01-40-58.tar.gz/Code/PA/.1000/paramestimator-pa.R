library("ks")
library("igraph")
library("parallel")
library("memoise")
source("../../../privatestat/statGraph/R/common.R")
source("../../../privatestat/statGraph/R/graph.param.estimator.R")

#anogva

niter <- 10
ncores <- 50

PA <- function(n, p)
{
	M <- as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=2)))
	N <- t(as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=2))))
	M[upper.tri(M)] <- 0
	N[lower.tri(N)] <- 0
	O <- M + N
	return(O)
}
Thread <- function(thread){
	cat("Starting thread ", thread, "\n")
	p_values <- c()
	q_values <- c()
	for(i in 1:niter){
		G <- PA(1000, 0.5)
		result <- graph.param.estimator(G=G, model=PA, parameters=list(min=c(0.1), max=c(1.9), eps=c(0.05)), directed=TRUE, distance="L1",npoints=200, ngraphs=30, use_grid_optimization = TRUE, grid_optimization_parameters = list("min" = 0.1, "max" = 1.9, "spacing" = 0.05), log=TRUE)
		print(result)

		params <- result$param
		filename = paste("paramestimator-pa-1000-progress-", thread, ".data", sep="")
		f <- file(filename, "a")
		writeLines(paste("Iteration: ", i, sep=""), f)
		writeLines(paste(params, sep="-"), f)
		close(f)

		p_values <- c(p_values, result$param[1])
	}
	filename = paste("paramestimator-pa-1000-core-p-", thread, ".data", sep="")
	write(x=p_values, file=filename)
}

s <- system.time ({mn <- mclapply(1:ncores, Thread, mc.cores=ncores)});
