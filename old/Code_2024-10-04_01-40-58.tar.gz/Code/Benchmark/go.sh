#!/bin/bash
Rscript go.R 5
Rscript go.R 6
