library("ks")
library("rbenchmark")
library("igraph")
library("parallel")
library("memoise")
library("pracma")
library("cluster")
library("aricode")
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/common.R")
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/graph.param.estimator.R")
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/graph.param.distance.R")
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/permanogva.R")
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/anogva.R")
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/graph.model.selection.R")

NCORES <- 50

ER <- function(n, p)
{
    M <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
    N <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
    M[upper.tri(M)] <- 0
    N[lower.tri(N)] <- 0
    O <- M + N
    return(O)
}
PA <- function(n, p)
{
    m <- n/10
	M <- as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=m)))
	N <- t(as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=m))))
	M[upper.tri(M)] <- 0
	N[lower.tri(N)] <- 0
	O <- M + N
	return(O)
}
WS <- function(n, p)
{
    nei = n / 10
	M <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p)))
	N <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p)))
	M[upper.tri(M)] <- 0
	N[lower.tri(N)] <- 0
	O <- M + N
	return(O)
}

param.estimator <- function(N, Model = ER, p = 0.35, search_domain = list(seq(0.1, 0.9, 0.01)), model_name = "ER"){
	cat("Starting thread; N = ", N, "\n")
	G <- Model(N, p)
	result <- graph.param.estimator(G=G, 
					model=Model, 
					parameters=search_domain, 
					directed=TRUE, 
					distance="L1",
					npoints=300, 
					ngraphs=5,
					from=c(-1, -1),
					to=c(1, 1),
					log=FALSE,
					search_mode="grid_search")
	p_value <- result$param[1]
	filename = paste("directed-out/simulation.param.estimator-", model_name, "-", N, "-result.data", sep="")
	write(x=p_value, file=filename, append=TRUE)
}

model.selection <- function(N, Model = ER, p = 0.35, model_list = list(ER, PA, WS), search_domain = list(seq(0.1, 0.9, 0.01), seq(0.1, 0.9, 0.01), seq(0.1, 0.9, 0.01)), model_name = "ER")
{
    cat("Starting thread; N = ", N, "\n")
    G <- Model(N, p)
    result <- graph.model.selection(G, 
                                    model_list, 
                                    search_domain, 
                                    directed=TRUE, 
                                    from=c(-1, -1), 
                                    to=c(1, 1),
                                    search_mode="grid_search")

    GIC <- result$estimates[,2]
	filename = paste("directed-out/simulation.model.selection-", model_name, "-", N, "-result.data", sep="")
    write.csv(GIC, filename, row.names=FALSE)
}

bench.param.estimator <- function(N) {
    b <- benchmark( param.estimator(N), replications = rep(1, 30) )
    filename = paste("directed-time/bench.param.estimator-", N, "-result.data", sep="")
    write.table(as.data.frame(b), file=filename)
}

bench.model.selection <- function(N) {
    b <- benchmark( model.selection(N), replications = rep(1, 30) )
    filename = paste("directed-time/bench.model.selection-", N, "-result.data", sep="")
    write.table(as.data.frame(b), file=filename)
}

launch.param.estimator <- function(){
    space <- seq(100, 500, 5)
    mclapply(space, bench.param.estimator, mc.cores=NCORES);
}

launch.model.selection <- function(){
    space <- seq(100, 500, 5)
    mclapply(space, bench.model.selection, mc.cores=NCORES);
}
