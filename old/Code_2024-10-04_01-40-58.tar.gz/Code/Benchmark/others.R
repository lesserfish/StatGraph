library(parallel)
library(igraph)
library(magrittr)
library(ks)
library(rbenchmark)

NCORES <- 10

DirectedEnv <- new.env()
source("/home/vchavauty/R/Network-Paper/privatestat/statGraph/R/common.R", local = DirectedEnv)

preGenerateGraphs <- function(K, model, n, p, directed){
  output <- list()
  if(directed){
    M <- function(n, p, model) {
      ER <- function(n, p)
      {
        M <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
        N <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
        M[upper.tri(M)] <- 0
        N[lower.tri(N)] <- 0
        O <- M + N
        return(O)
      }
      PA <- function(n, p)
      {
        m <- n/10
        M <- as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=m)))
        N <- t(as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=m))))
        M[upper.tri(M)] <- 0
        N[lower.tri(N)] <- 0
        O <- M + N
        return(O)
      }
      WS <- function(n, p)
      {
        nei = n / 10
        M <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p)))
        N <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p)))
        M[upper.tri(M)] <- 0
        N[lower.tri(N)] <- 0
        O <- M + N
        return(O)
      }
      
      if(model == "ER") return(ER(n, p))
      if(model == "PA") return(PA(n, p))
      if(model == "WS") return(WS(n, p))
    }
    
    for(i in 1:K){
      output[[i]] <- M(n, p, model)
    }
    
    return(output)
  }
  else {
    M <- function(n, p, model) {
      
      ER <- function(n, p)
      {
        M <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
        return(M)
      }
      PA <- function(n, p)
      {
        m <- n / 10
        M <- as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=m)))
        return(M)
      }
      
      WS <- function(n, p)
      {
        nei <- n / 10
        M <- as.matrix(igraph::as_adj(igraph::sample_smallworld(dim=1, size=n, nei=nei, p=p)))
        return(M)
      }
      
      if(model == "ER") return(ER(n, p))
      if(model == "PA") return(PA(n, p))
      if(model == "WS") return(WS(n, p))
      
    }
    
    for(i in 1:K){
      output[[i]] <- M(n, p, model)
    }
    
    return(output)
  }
}

bench.spectrum.directed <- function(N, K = 100, model = "ER", p = 0.35){
  graphs <- preGenerateGraphs(K, model, N, p, TRUE)
  
  bench.function <- function(){
    print("Starting bench...")
    index <- sample(1:K, 1)
    G <- graphs[[index]]
    
    DirectedEnv$spectralDensity(G, from=c(-1, -1), to=c(1, 1), npoints=512, directed=TRUE)
  }
  
  bench <- benchmark ( { bench.function() }, replications = rep(1, 20) )
  filename <- paste("directed-time/bench.spectrum-", N, "-result.data", sep="")
  print(bench)
  write.table(as.data.frame(bench), file=filename)
}

bench.spectrum.undirected <- function(N, K = 100, model = "ER", p = 0.35){
  graphs <- preGenerateGraphs(K, model, N, p, FALSE)
  
  bench.function <- function(){
    print("Starting bench...")
    index <- sample(1:K, 1)
    G <- graphs[[index]]
    
    DirectedEnv$spectralDensity(G, from=-1, to=1, npoints=512, directed=FALSE)
  }
  
  bench <- benchmark ( { bench.function() }, replications = rep(1, 20) )
  filename <- paste("undirected-time/bench.spectrum-", N, "-result.data", sep="")
  print(bench)
  write.table(as.data.frame(bench), file=filename)
}

launch.spectrum.directed <- function(){
  space <- seq(100, 500, 5)
  mclapply(space, bench.spectrum.directed, mc.cores=NCORES)
}

launch.spectrum.undirected <- function(){
  space <- seq(100, 500, 5)
  mclapply(space, bench.spectrum.undirected, mc.cores=NCORES)
}

