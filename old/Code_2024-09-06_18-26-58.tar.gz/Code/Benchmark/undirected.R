library("igraph")
library("statGraph")
library("parallel")
library("rbenchmark")

NCORES <- 50

ER <- function(n, p)
{
    M <- igraph::sample_gnp(n, p)
    return(M)
}


param.estimator <- function(N, Model = ER, p = 0.35, interval=seq(0.1, 0.9, 0.01), model_name = "ER"){
	cat("Starting thread; N = ", N, "\n")
	G <- Model(N, p)
	result <- statGraph::graph.param.estimator(Graph=G, 
					model=Model, 
                    interval=interval)

	p_value <- result$param
	filename = paste("undirected-out/simulation.param.estimator-", model_name, "-", N, "-result.data", sep="")
	write(x=p_value, file=filename, append=TRUE)
}

bench.param.estimator <- function(N) {
    b <- benchmark( param.estimator(N), replications = rep(1, 30) )
	filename = paste("undirected-time/bench.param.estimator-", N, "-result.data", sep="")
    write.table(as.data.frame(b), file=filename)
}

launch.param.estimator <- function(){
    space <- seq(100, 500, 5)
	mclapply(space, bench.param.estimator, mc.cores=NCORES);
}
