args <- commandArgs(trailingOnly = TRUE)
arg1 <- args[1]  # Get the first argument

OPTION <- arg1

cat("Launching with OPTION: ", OPTION, "\n")

if(OPTION == 1){
    source("./directed.R")
    launch.param.estimator()
}

if(OPTION == 2){
    source("./undirected.R")
    launch.param.estimator()
}
