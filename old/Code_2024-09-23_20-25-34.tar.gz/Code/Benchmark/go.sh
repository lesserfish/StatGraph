#!/bin/bash
Rscript go.R 3
Rscript go.R 4
