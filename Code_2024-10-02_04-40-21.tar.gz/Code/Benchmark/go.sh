#!/bin/bash
Rscript go.R 6
