args <- commandArgs(trailingOnly = TRUE)
arg1 <- args[1]  # Get the first argument

OPTION <- arg1

cat("Launching with OPTION: ", OPTION, "\n")

if(OPTION == 1){
    source("./directed.R")
    launch.param.estimator()
}

if(OPTION == 2){
    source("./undirected.R")
    launch.param.estimator()
}

if(OPTION == 3){
    source("./directed.R")
    launch.model.selection()
}

if(OPTION == 4){
    source("./undirected.R")
    launch.model.selection()
}


if(OPTION == 5){
    source("./others.R")
    launch.spectrum.directed()
}

if(OPTION == 6){
    source("./others.R")
    launch.spectrum.undirected()
}
