source("~/R/Network-Paper/New/simulation.R")

mcfunc <- function(i)
{
    setwd("./TMP3")
    if(i == 1){
                simulation.kmedoids(100, 0.2,seq(0, 0.2, length.out=30), 20, 20 ,PA(10), "PA")
    }
    if(i == 2){
                simulation.kmedoids(300, 0.2,seq(0, 0.2, length.out=30), 20, 20, PA(30), "PA")
    }
    if(i == 3){
                simulation.kmedoids(500, 0.2,seq(0, 0.2, length.out=30), 20, 20, PA(50), "PA")
    }
    if(i == 4){
                simulation.kmedoids(800, 0.2,seq(0, 0.2, length.out=30), 20, 20, PA(80), "PA")
    }
    if(i == 5){
                simulation.kmedoids(100, 0.2,seq(0, 0.03, length.out=30), 20, 20, WS(10), "WS")
    }
    if(i == 6){
                simulation.kmedoids(300, 0.2,seq(0, 0.03, length.out=30), 20, 20, WS(30), "WS")
    }
    if(i == 7){
                simulation.kmedoids(500, 0.2,seq(0, 0.03, length.out=30), 20, 20, WS(50), "WS")
    }
    if(i == 8){
                simulation.kmedoids(800, 0.2,seq(0, 0.03, length.out=30), 20, 20, WS(80), "WS")
    }
    if(i == 9){
                simulation.kmedoids(100, 0.2,seq(0, 0.03, length.out=30), 20, 20, ER, "ER")
    }
    if(i == 10){
                simulation.kmedoids(300, 0.2,seq(0, 0.03, length.out=30), 20, 20, ER, "ER")
    }
    if(i == 11){
                simulation.kmedoids(500, 0.2,seq(0, 0.03, length.out=30), 20, 20, ER, "ER")
    }
    if(i == 12){
                simulation.kmedoids(800, 0.2,seq(0, 0.03, length.out=30), 20, 20, ER, "ER")
    }




    if(i == 13){
                simulation.kmedoids(100, 0.2,seq(0, 0.3, length.out=30), 20, 20 ,PA(10), "Easy-PA")
    }
    if(i == 14){
                simulation.kmedoids(300, 0.2,seq(0, 0.3, length.out=30), 20, 20, PA(30), "Easy-PA")
    }
    if(i == 15){
                simulation.kmedoids(500, 0.2,seq(0, 0.3, length.out=30), 20, 20, PA(50), "Easy-PA")
    }
    if(i == 16){
                simulation.kmedoids(800, 0.2,seq(0, 0.3, length.out=30), 20, 20, PA(80), "Easy-PA")
    }
    if(i == 17){
                simulation.kmedoids(100, 0.2,seq(0, 0.05, length.out=30), 20, 20, WS(10), "Easy-WS")
    }
    if(i == 18){
                simulation.kmedoids(300, 0.2,seq(0, 0.05, length.out=30), 20, 20, WS(30), "Easy-WS")
    }
    if(i == 19){
                simulation.kmedoids(500, 0.2,seq(0, 0.05, length.out=30), 20, 20, WS(50), "Easy-WS")
    }
    if(i == 20){
                simulation.kmedoids(800, 0.2,seq(0, 0.05, length.out=30), 20, 20, WS(80), "Easy-WS")
    }
    if(i == 21){
                simulation.kmedoids(100, 0.2,seq(0, 0.05, length.out=30), 20, 20, ER, "Easy-ER")
    }
    if(i == 22){
                simulation.kmedoids(300, 0.2,seq(0, 0.05, length.out=30), 20, 20, ER, "Easy-ER")
    }
    if(i == 23){
                simulation.kmedoids(500, 0.2,seq(0, 0.05, length.out=30), 20, 20, ER, "Easy-ER")
    }
    if(i == 24){
                simulation.kmedoids(800, 0.2,seq(0, 0.05, length.out=30), 20, 20, ER, "Easy-ER")
    }
    return()
}

launch.simulation(mcfunc, 24)

