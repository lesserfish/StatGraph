library("ks")
library("igraph")
library("parallel")
library("memoise")
source("../../../privatestat/statGraph/R/common.R")
source("../../../privatestat/statGraph/R/graph.param.estimator.R")
source("../../../privatestat/statGraph/R/graph.param.distance.R")

ER <- function(n, p)
{
    M <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
    N <- as.matrix(igraph::as_adj(igraph::sample_gnp(n, p)))
    M[upper.tri(M)] <- 0
    N[lower.tri(N)] <- 0
    O <- M + N
    return(O)
}

PA <- function(n, p)
{
	M <- as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=10)))
	N <- t(as.matrix(igraph::as_adj(igraph::sample_pa(n=n, power=1 * p + 0.001, m=10))))
	M[upper.tri(M)] <- 0
	N[lower.tri(N)] <- 0
	O <- M + N
	return(O)
}

WS <- function(n, p)
{
    M <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=50, p=p)))
    N <- as.matrix(igraph::as_adjacency_matrix(igraph::sample_smallworld(dim=1, size=n, nei=50, p=p)))
    M[upper.tri(M)] <- 0
    N[lower.tri(N)] <- 0
    O <- M + N
    return(O)
}


simulation.size.variance <- function(N, Model, p, search_domain, niter, model_name){
	cat("Starting analysis with size ", N, "\n")
	p_values <- c()
	q_values <- c()

	ncols <- length(search_domain[[1]])
	nrows <- niter

	output <- matrix(0, nrow=nrows, ncol=ncols)
	
	for(i in 1:niter){

		G <- Model(N, p)
		result <- graph.param.distance(G=G, 
                                        model=Model, 
                                        parameters=search_domain, 
                                        directed=TRUE, 
                                        distance="L1",
                                        npoints=300, 
                                        ngraphs=5,
                                        from=c(-1, -1),
                                        to=c(1, 1),
                                        log=FALSE,
                                        search_mode="grid_search")
		output[i, ] <- result$distance
        # Log progress
		filename = paste("simulation.size.variance-", model_name, "-", N, "-progress-.data", sep="")
		write.csv(output, filename, row.names=FALSE)
	}
	filename = paste("simulation.size.variance-", model_name, "-", N, "-progress-.data", sep="")
	write.csv(output, filename, row.names=FALSE)
}


launch.simulation <- function(ncores, n_values...){
    s <- system.time ({mn <- mclapply(1:n_values, simulation, ..., mc.cores=ncores)});
}
